const router = require('express').Router();
const User = require('../models/User');

router.get('/', (req, res) => {
    res.render('register', {
        title: "Register",
        css: "register"
    });
});

router.post('/', async (req, res) => {
    const firstName = req.body.firstname;
    const lastName = req.body.lastname;
    const userName = req.body.username;
    const email = req.body.email;
    const password = req.body.password;
    const confirm_password = req.body.confirm_password;

    if (!firstName || !lastName || !userName || !email || !password || !confirm_password)
        return res.redirect('/register');

    if (confirm_password !== password)
        return res.redirect('/register');

    try {
        let user = await User.findOne({ username: userName });

        if (user) return res.redirect('/register');

        user = new User({
            name: firstName + " " + lastName,
            username: userName,
            email: email,
            password: password
        });

        user = await user.save();
        console.log(`User created:\n${user}`);

        res.redirect('login');
    } catch (err) {
        return console.log(err);
    }
});

module.exports = router;