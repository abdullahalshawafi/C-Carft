const router = require('express').Router();
const User = require('../models/User');

router.get('/', (req, res) => {
    res.render('login', {
        title: "Log In",
        css: "login"
    });
});

router.post('/', (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    User.findOneAndDelete({ email: email, password: password }, (err, user) => {
        if (err) return console.log(err);
        if (!user) return res.redirect('/login');

        console.log(user.name + ' user is deleted');
        res.redirect('/');
    });

});

module.exports = router;