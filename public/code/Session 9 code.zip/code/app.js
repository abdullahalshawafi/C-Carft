const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();

const port = 8000;

mongoose.connect('mongodb://localhost/Session9', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function () {
    console.log('Connected to DB');
});

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
    res.render('home', {
        title: 'Home',
        css: 'home'
    });
});

const registerRoutes = require('./routes/register');
const loginRoutes = require('./routes/login');

app.use('/register', registerRoutes);
app.use('/login', loginRoutes);

app.listen(port, err => {
    if (err) return console.log(err);
    console.log(`Server started listening at ${port}`);
});