const express = require('express');
const app = express();

const port = process.env.PORT || 4000;

app.get('/', (req, res) => {
    res.send("<h1>Hello user from root</h1>");
});

app.get('/home', (req, res) => {
    res.send("<h2>Hello user from home</h2>");
});

app.get('/profile/:personName', (req, res) => {
    const name = req.params.personName;
    res.send("<h2>Hello " + name + "</h2>");
});

app.listen(port, (err) => {
    if (err) return console.log(err);
    console.log(`Listening at port ${port}`);
});