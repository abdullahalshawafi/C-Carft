/*
*  Open the console in your browser to see the logs
*/

const body = document.body;
const header = document.getElementById('header');
const view_button = document.getElementsByTagName('button')[0];
const hide_button = document.getElementsByTagName('button')[1];
const container = document.getElementsByClassName('container');
const hidden_input = document.getElementsByName('hidden-input')[0];
const imgcontainer = document.querySelector('.imgContainer');
const buttons = document.querySelectorAll('.container button');

////////////////////////////////////////////////////////////
//////Uncomment the two lines below to see there effect/////
////////////////////////////////////////////////////////////

// const age = window.prompt("How old are you?");
// window.alert("You are " + age.toString() + " years old");

console.log("A lot of console logs are coming for you");
console.log(body);
console.log(view_button);
console.log(hide_button);
console.log(container);
console.log(container[0]);
console.log(hidden_input);
console.log(imgcontainer);
console.log(buttons);

hide_button.addEventListener('click', function () {
    if (imgcontainer.childNodes.length !== 0)
        imgcontainer.childNodes[0].remove();
});

function displayImage() {
    if (imgcontainer.childNodes.length === 0) {
        const image = document.createElement('img');
        image.setAttribute('src', './images/CMP-Logo.png');
        image.setAttribute('alt', 'Logo Image');
        image.setAttribute('style', 'width: 200px;');
        imgcontainer.appendChild(image);
    }
}
