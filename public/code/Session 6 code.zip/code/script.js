//sync vs async
//callbacks
//promises
//async await

//sync
const Print = () => {
    console.log('getting data');
    console.log('processing data');
    console.log('returning data');
}

console.log('begin');

Print();

console.log('finish');

//async

/* callbacks */
const viewPost = (postTitle, callback) => {
    setTimeout(() => {
        console.log('Post viewed');
        callback(postTitle);
    }, 1000);
};

const viewUser = (postOwner, callback) => {
    setTimeout(() => {
        console.log('Owner viewed');
        callback(postOwner);
    }, 1000);
};

const viewUserPassword = (postOwnerPassword, callback) => {
    setTimeout(() => {
        console.log("Owner's password viewed");
        callback(postOwnerPassword.password);
    }, 1000);
};

const user = {
    name: "admin",
    email: "admin@admin.com",
    password: "as;ldkfj"
}

console.log('begin');

viewPost("First post", (title) => {
    console.log(title);
    viewUser(user, (owner) => {
        console.log(owner.email);
        viewUserPassword(user, (password) => {
            console.log(password);
        });
    });
});

console.log('finish');

/* promises */
const condition1 = true;
const condition2 = true;
const condition3 = true;

const viewPost = (postTitle) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (condition1) {
                console.log('Post viewed');
                resolve(postTitle);
            } else {
                reject(new Error('post not found'));
            }
        }, 1000);
    });
};

const viewUser = (postOwner) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (condition2) {
                console.log('Owner viewed');
                resolve(postOwner);
            } else {
                reject(new Error('user not found'));
            }
        }, 1000);
    });
};

const viewUserPassword = (postOwnerPassword) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (condition3) {
                console.log("Owner's password viewed");
                resolve(postOwnerPassword.password);
            } else {
                reject(new Error('password not found'));
            }
        }, 1000);
    });
};

const user = {
    name: "admin",
    email: "admin@admin.com",
    password: "as;ldkfj"
}

console.log('begin');

viewPost("First title")
    .then(title => {
        console.log(title);
        return viewUser(user);
    })
    .then((owner) => {
        console.log(owner.email);
        return viewUserPassword(user);
    })
    .then((password) => {
        console.log(password);
    })
    .catch(error => {
        console.log(error);
    });

console.log('finish');

/* async await */
const condition1 = true;
const condition2 = false;
const condition3 = true;

const viewPost = (postTitle) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (condition1) {
                console.log('Post viewed');
                resolve(postTitle);
            } else {
                reject(new Error('post not found'));
            }
        }, 1000);
    });
};

const viewUser = (postOwner) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (condition2) {
                console.log('Owner viewed');
                resolve(postOwner.email);
            } else {
                reject(new Error('user not found'));
            }
        }, 1000);
    });
};

const viewUserPassword = (postOwnerPassword) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (condition3) {
                console.log("Owner's password viewed");
                resolve(postOwnerPassword.password);
            } else {
                reject(new Error('password not found'));
            }
        }, 1000);
    });
};

const user = {
    name: "admin",
    email: "admin@admin.com",
    password: "as;ldkfj"
}

async function ourFunction() {
    const title = await viewPost('First title');
    console.log(title);
    const user_email = await viewUser(user);
    console.log(user_email);
    const user_password = await viewUserPassword(user);
    console.log(user_password);
}

console.log('begin');

ourFunction();

console.log('finish');