const router = require('express').Router();
const User = require('../models/User');

// GET /users
router.get('/', async (req, res) => {
    try {
        const users = await User.find({});

        res.render('users', {
            title: "Users",
            css: "users",
            users: users
        });
    } catch (err) {
        return console.log(err);
    }
});

// GET /users/username
router.get('/:username', async (req, res) => {
    try {
        const user = await User.findOne({ username: req.params.username });

        if (!user) {
            req.flash('danger', 'There is no such user')
            return res.redirect('/register');
        }

        res.render('user-profile', {
            title: user.name,
            css: "user-profile",
            user: user
        });
    } catch (err) {
        return console.log(err);
    }
});

module.exports = router;