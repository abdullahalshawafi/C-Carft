const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const User = require('../models/User');

// GET /register
router.get('/', (req, res) => {
    res.render('register', {
        title: "Register",
        css: "register"
    });
});

// POST /register
router.post('/', [
    body('firstname', 'fisrt name is missing').notEmpty(),
    body('firstname', 'first name should be at least 2 characters long').isLength({ min: 2 }),
    body('firstname', 'first name should not be more than 200 characters long').isLength({ max: 200 }),
    body('lastname', 'last name is missing').notEmpty(),
    body('lastname', 'last name should be at least 2 characters long').isLength({ min: 2 }),
    body('lastname', 'last name should not be more than 200 characters long').isLength({ max: 200 }),
    body('username', 'username is missing').notEmpty(),
    body('username', 'username should be at least 5 characters long').isLength({ min: 5 }),
    body('username', 'username should not be more than 200 characters long').isLength({ max: 200 }),
    body('email', 'email is missing').notEmpty(),
    body('email', 'Please enter a valid email').isEmail(),
    body('password', 'password is missing').notEmpty(),
    body('password', 'password should be at least 7 characters long').isLength({ min: 7 }),
    body('password', 'password should not be more than 200 characters long').isLength({ max: 200 }),
    body('confirm_password', 'confirm password is missing').notEmpty(),
    body('confirm_password', 'Passwords are not equal').not().equals('password')
], async (req, res) => {
    const firstName = req.body.firstname;
    const lastName = req.body.lastname;
    const userName = req.body.username;
    const email = req.body.email;
    const password = req.body.password;
    const confirm_password = req.body.confirm_password;

    const errors = validationResult(req).errors;

    if (errors.length) {
        return res.render('register', {
            title: "Register",
            css: "register",
            errors: errors,
            firstname: firstName,
            lastname: lastName,
            username: userName,
            email: email
        })
    }

    try {
        let user = await User.findOne({ username: userName });

        if (user) {
            req.flash('danger', 'Username is already taken');
            return res.redirect('/register');
        }

        user = await User.findOne({ email: email });

        if (user) {
            req.flash('danger', 'Email is already registered');
            return res.redirect('/register');
        }

        user = new User({
            name: firstName + " " + lastName,
            username: userName,
            email: email,
            password: password
        });

        const salt = await bcrypt.genSalt();
        const hashedPassword = await bcrypt.hash(user.password, salt);
        user.password = hashedPassword;

        user = await user.save();

        req.flash('success', 'You registered successfully');
        res.redirect('/login');
    } catch (err) {
        return console.log(err);
    }
});

module.exports = router;