const router = require('express').Router();
const bcrypt = require('bcryptjs');
const User = require('../models/User');

// GET /login
router.get('/', (req, res) => {
    res.render('login', {
        title: "Log In",
        css: "login"
    });
});

// POST /login
router.post('/', async (req, res) => {
    const username = req.body.username;
    const password = req.body.password;

    try {
        let user = await User.findOne({ username: username });

        if (!user) {
            req.flash('danger', 'Wrong username');
            return res.redirect('/login');
        }

        const correctPassword = await bcrypt.compare(password, user.password);

        if (!correctPassword) {
            req.flash('danger', 'Wrong password');
            return res.redirect('/login');
        }

        res.redirect('users/' + user.username);

    } catch (err) {
        return console.error(err);
    }
});

module.exports = router;