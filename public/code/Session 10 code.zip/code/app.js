const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const session = require('express-session');

const app = express();

const port = 8080;

// Connecting to DB
mongoose.connect('mongodb://localhost/Session10', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
    console.log('Connected to DB');
});

// Setting up public folder
app.use(express.static(path.join(__dirname, 'public')));

// Body-parser middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Session middleware
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true
}));

// Flash messages middleware
app.use(require('connect-flash')());
app.use((req, res, next) => {
    res.locals.messages = require('express-messages')(req, res);
    next();
});

// Setting up the views
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// GET / "Home"
app.get('/', (req, res) => {
    res.render('home', {
        title: 'Home',
        css: 'home'
    });
});

// GET /deleteALL
app.get('/deleteAll', (req, res) => {
    require('./models/User').deleteMany({}, err => {
        if (err) return console.log(err);
    });

    res.render('home', {
        title: 'Home',
        css: 'home'
    });
});

// Routes
app.use('/register', require('./routes/register'));
app.use('/login', require('./routes/login'));
app.use('/users', require('./routes/users'));

// Listening to requests
app.listen(port, err => {
    if (err) return console.log(err);
    console.log(`Server started listening at ${port}`);
});