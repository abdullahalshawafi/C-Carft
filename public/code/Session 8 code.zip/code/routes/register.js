const router = require('express').Router();

router.get('/', (req, res) => {
    res.render('register', {
        title: "Register",
        css: "register"
    });
});

module.exports = router;