///////////////////////////////////////////////////////////////////////////////////////////////
//String and their methods
let x = 500;
console.log(x + "50");  //returns 50050 (concatenation)
console.log(x - "50");  //returns 450   (arithmetic operation)
console.log(x * "50");  //returns 25000 (arithmetic operation)
console.log(x / "50");  //returns 10    (arithmetic operation)

const string = "and and and and CMP";
console.log(string.length);                 //returns 19
console.log(string.indexOf('CMP'));         //returns 16
console.log(string.lastIndexOf('d'));       //returns 14
console.log(string.search('d'));            //returns 2
console.log(string.slice(0, -1));           //returns "and and and and CM"
console.log(string.substr(0, 3));           //returns "and"
console.log(string);                        //returns "and and and and CMP"
console.log(string.replace('and', 'AND'));  //retunrs "AND and and and CMP"
console.log(string.replace(/and/g, 'AND')); //retunrs "AND AND AND AND CMP"
console.log(string.charAt(16));             //returns "C"
console.log(string.charCodeAt(16));         //returns 67
console.log(string.split(" "));             //returns ["and", "and", "and", "and", "CMP"]
console.log(string.toUpperCase());          //returns "AND AND AND AND CMP"
console.log(string.toLowerCase());          //returns "and and and and cmp"

///////////////////////////////////////////////////////////////////////////////////////////////
//Numbers and their methods
let number = 500;
console.log(number);                        //returns 500
console.log(typeof number);                 //returns number
console.log(number.toString());             //returns "500"
console.log(typeof number.toString());      //returns string
console.log(number.toExponential(5));       //returns "5.00000e+2"
console.log(number.toFixed(5));             //returns "500.00000"
console.log(number.toPrecision(7));         //returns "500.0000"

let numberString = "200.6";
console.log(Number(numberString));          //returns 200.6
console.log(typeof Number(numberString));   //returns number
console.log(parseFloat(numberString));      //returns 200.6
console.log(parseInt(numberString));        //returns 200

///////////////////////////////////////////////////////////////////////////////////////////////
//Arrays and their methods
let myArray = [1, 2, 4, 5];
console.log(typeof myArray);            //returns object
console.log(Array.isArray(myArray));    //returns true
console.log(myArray.toString());        //returns "1,2,4,5"
console.log(myArray.join(" "));         //returns "1 2 4 5"
console.log(myArray.pop());             //returns 5
console.log(myArray);                   //returns [1, 2, 4]
console.log(myArray.push(5));           //returns 4
console.log(myArray);                   //returns [1, 2, 4, 5]
console.log(myArray.shift());           //returns 1
console.log(myArray);                   //returns [2, 4, 5]
console.log(myArray.unshift(1));        //returns 4
console.log(myArray);                   //returns [1, 2, 4, 5]
console.log(myArray.length);            //returns 4
myArray.splice(2, 2, 3, 4, 5);
console.log(myArray);                   //returns [1, 2, 3, 4, 5]

let array2 = [6, 7], array3 = [8, 9];
let bigArray = myArray.concat(array2, array3);
console.log(bigArray);                                  //returns [1, 2, 3, 4, 5, 6, 7, 8, 9]
console.log(bigArray.slice(4));                         //returns [5, 6, 7, 8, 9]
console.log(bigArray.slice(4, 7));                      //returns [5, 6, 7]

let arrayStrings = ["Menna", "Ali", "Ahmed"];
let arrayNumbers = [100, 50, 25, 200, 350];
console.log(arrayStrings.sort());                       //returns ["Ahmed", "Ali", "Menna"]
console.log(arrayStrings.sort().reverse());             //returns ["Menna", "Ali", "Ahmed"]


console.log(arrayNumbers.sort(function (num1, num2) {   //
    return num1 - num2;                                 //returns [25, 50, 100, 200, 350]
}));                                                    //

console.log(arrayNumbers.sort(function (num1, num2) {   //
    return num2 - num1;                                 //returns [350, 200, 100, 50, 25]
}));                                                    //

//Now arrayNumbers = [350, 200, 100, 50, 25]

let fruits = ["Apple", "Banana", "Orange"];
fruits.forEach(function (fruit, index) {
    console.log(fruit, index);
});

let FRUITS = fruits.map(function (fruit) {
    return fruit.toUpperCase();
});

console.log(fruits);    //returns ["Apple", "Banana", "Orange"]
console.log(FRUITS);    //returns ["APPLE", "BANANA", "ORANGE"]

console.log(arrayNumbers.filter(function (number) {     //
    return number > 50;                                 //returns [350, 200, 100]
}));                                                    //

console.log(arrayNumbers.reduce(function (Sum, number) {//
    return Sum + number;                                //returns 725
}));                                                    //

console.log(arrayNumbers.every(function (number) {      //
    return number > 10;                                 //returns true
}));                                                    //

console.log(arrayNumbers.some(function (number) {       //
    return number > 50;                                 //returns true
}));                                                    //

console.log(arrayNumbers.find(function (number) {       //
    return number > 100;                                //returns 350
}));                                                    //

console.log(arrayNumbers.findIndex(function (number) {  //
    return number > 100;                                //returns 0
}));                                                    //

///////////////////////////////////////////////////////////////////////////////////////////////
//Objects and their methods
let users = [
    {
        first_name: "Abdullah",
        job: "Student",
        age: 20
    },
    {
        first_name: "Ahmed",
        job: "Student",
        age: 20
    },
    {
        first_name: "Reem",
        job: "Student",
        age: 20
    },
    {
        first_name: "Menna",
        job: "Student",
        age: 20
    },
    {
        first_name: "Mahmoud",
        job: "Student",
        age: 20
    },
];
console.log(users[0].first_name);       //returns "Abdullah"
console.log(users[1]["first_name"]);    //returns "Ahmed"
console.log(Object.values(users[1]));   //returns ["Ahmed", "Student", 20]

//****Open the console to see****
users.forEach(function (user) {
    for (property in user) {
        console.log(user[property]);
    }
});

users.forEach(function (user) {
    for (property in user) {
        user.graduation_year = 2023;
    }
});

users.forEach(function (user) {
    for (property in user) {
        console.log(user[property]);
    }
});

users.forEach(function (user) {
    for (property in user) {
        delete user.graduation_year;
    }
});

users.forEach(function (user) {
    for (property in user) {
        console.log(user[property]);
    }
});
///////////////////////////////////////////////////////////////////////////////////////////////